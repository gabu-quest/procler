# Changelog

All notable changes to The Style will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-12-21

### Added
- **Initial release** - Extracted from The Standard repository
- **Goshuin Edition** - Ceremonial & calm design system
  - Crimson and gold color palette
  - Cormorant Garamond + Inter typography
  - Bold icon weights only
  - Complete token system and Naive UI theme
- **Cyberpunk Edition** - Neon & rebellious design system
  - Hot pink, cyan, purple color palette
  - Space Grotesk + Inter typography
  - Duotone icon support with varied weights
  - Complete token system and Naive UI theme
- Complete documentation for both variants
- Vue 3 integration examples
- Phosphor icons integration

---

## Future Releases

Planned improvements:
- Light mode support for both variants
- Additional color themes
- Component library examples
- Storybook integration
- Accessibility audit tools

# The Style

**Vue 3 + Naive UI Design Systems**

Two complete, production-ready design systems with distinct aesthetic philosophies. Choose the one that matches your project's visual identity.

---

## Quick Start

**1. Choose Your Variant:**
- **[Goshuin](./goshuin/)** - Ceremonial & calm (crimson, gold, serif)
- **[Cyberpunk](./cyberpunk/)** - Neon & rebellious (pink, cyan, geometric)

**2. Install Dependencies:**
```bash
pnpm add naive-ui @phosphor-icons/vue
```

**3. Copy Files:**
```bash
# Copy your chosen variant's design system
cp -r goshuin/src/design ./src/
# or
cp -r cyberpunk/src/design ./src/
```

**4. Integrate:**
See [Comparison & Integration Guide](#comparison--integration) below.

---

## Variants

### Goshuin Edition - Ceremonial & Calm

**Philosophy:** Ink, stamps, ceremony, cultural heritage

**Best for:** Content platforms, documentation, enterprise apps seeking calm authority

**Colors:** Crimson (#D32F2F), gold leaf, charcoal, warm cream
**Typography:** Cormorant Garamond (headings), Inter (body)
**Icons:** Bold weights only (stamped permanence)

[→ Goshuin Documentation](./goshuin/docs/README.md)

---

### Cyberpunk Edition - Neon & Defiance

**Philosophy:** Neon grids, hacking aesthetics, digital rebellion

**Best for:** Dev tools, SaaS, gaming, tech-focused applications

**Colors:** Hot pink, cyan, purple, lime on deep black
**Typography:** Space Grotesk (headings), Inter (body)
**Icons:** Duotone + varied weights (layered complexity)

[→ Cyberpunk Documentation](./cyberpunk/docs/README.md)

---

## Comparison & Integration

| Aspect | Goshuin | Cyberpunk |
|--------|---------|-----------|
| **Mood** | Calm, ceremonial | Energetic, rebellious |
| **Colors** | Crimson, gold, charcoal | Pink, cyan, purple, black |
| **Typography** | Serif + sans | Geometric sans |
| **Icons** | Bold only | Duotone + varied weights |
| **Use Case** | Content, docs, enterprise | Dev tools, SaaS, gaming |

---

## Installation

Both variants follow the same integration pattern:

### 1. Install Dependencies
```bash
pnpm add naive-ui @phosphor-icons/vue
```

### 2. Copy Design System Files
```bash
# Choose your variant:
cp -r goshuin/src/design ./src/
# or
cp -r cyberpunk/src/design ./src/
```

### 3. Import Base CSS
```typescript
// In your main.ts or App.vue
import '@/design/base.css'
```

### 4. Wrap App with Config Provider
```vue
<script setup lang="ts">
import { NConfigProvider, darkTheme } from 'naive-ui'
import { createDsNaiveThemeOverrides } from '@/design/naive-theme'
import { providePhosphorDefaults } from '@/design/icons'

const themeOverrides = createDsNaiveThemeOverrides('dark')
providePhosphorDefaults() // Call during setup, not in onMounted
</script>

<template>
  <n-config-provider :theme="darkTheme" :theme-overrides="themeOverrides">
    <n-global-style />
    <n-message-provider>
      <router-view />
    </n-message-provider>
  </n-config-provider>
</template>
```

See `examples/AppConfigProvider.vue` in each variant for complete patterns.

---

## Common Features

Both design systems share the same architecture:

- **Token-based design** - Single source of truth in `src/design/tokens.ts`
- **Naive UI integration** - Theme overrides work seamlessly
- **Accessibility first** - WCAG AA contrast, focus states, reduced motion
- **Phosphor icons** - Tree-shakeable, provide/inject pattern
- **Complete documentation** - Full style guides + LLM-friendly sections

---

## Customization

Edit `src/design/tokens.ts` in your chosen variant:

```typescript
export const palette = {
  primary: "#YOUR_COLOR",
  accent: "#YOUR_ACCENT",
  // Theme overrides update automatically
}
```

---

## Migration Between Variants

Both use the same token structure:

1. Replace `src/design/` directory
2. Update fonts (if needed)
3. Review icon usage (Goshuin doesn't support duotone/thin)
4. Test edge cases

No component code changes needed.

---

## License

MIT License - Use freely in any project.

---

## Related

Part of [The Standard](https://github.com/gabu-quest/the-standard) - Engineering doctrine for AI-assisted software development.

# PATCH — Goshuin / Ceremonial Pack (Icons + Critical Provide Fix)

Audience: LLM agent patching the *Goshuin / Ceremonial* Naive UI design system pack.

Goal:
- Align Goshuin icons with the ceremonial “ink & stamp” physics.
- Fix a critical Vue provide() timing issue in the examples/integration pattern.

---

## A) Icon philosophy update (Goshuin Edition)

Goshuin is **material**:
- ink is deposited, not emitted
- authority is weight + permanence

Therefore:
- Default icon weight becomes **bold**
- `duotone` is **forbidden**
- `thin` is **forbidden**
- `fill` is allowed only for selected/toggled states

This differs from the Cyberpunk Edition, where duotone/thin have specific roles.

---

## B) Code changes (apply exactly)

### B1) Update `src/design/tokens.ts` (icons section)

Find `icons:` and replace it with this block:

```ts
icons: {
  // Ceremonial icons should feel stamped (weighty), not emissive.
  defaults: {
    color: "currentColor",
    size: "1.0em",
    weight: "bold" as const,
    mirrored: false,
  },
  size: {
    xs: "0.9em",
    sm: "1em",
    md: "1.0em",
    lg: "1.2em",
    xl: "1.45em",
    hero: "2em",
  },
  weight: {
    ui: "bold" as const,
    emphasis: "bold" as const,
    selected: "fill" as const,
    // decorative: (forbidden) — do not use duotone in Goshuin Edition
  },
},
```

Notes:
- We slightly reduced default size to compensate for bold stroke weight.
- We removed duotone/decorative weight; do not reintroduce it.

### B2) Fix provide() timing in root provider example

If your Goshuin pack includes an example like `examples/AppConfigProvider.vue` (or your app’s root setup),
ensure `providePhosphorDefaults()` is called **during setup**, not inside `onMounted`.

Replace:

```ts
onMounted(() => {
  providePhosphorDefaults();
});
```

with:

```ts
providePhosphorDefaults();
```

Rationale:
- Vue `provide()` must run during setup for descendants to reliably receive injected defaults.

---

## C) Docs changes (update the contract)

Update these files to match the new Goshuin icon rules:
- `docs/04_ICONS_PHOSPHOR.md`
- `docs/STYLE_GUIDE_FULL.md` (icons section, if present)

New rule text (copy/paste):

- Default weight: **bold**
- Selected/toggled: **fill**
- Do not use **duotone** or **thin** in Goshuin Edition

---

## D) Acceptance checklist (confirm after patch)

- Icon defaults render as bold without manual per-icon props.
- No duotone icons exist in Goshuin UI.
- Selected/toggled states use fill icons consistently.
- `providePhosphorDefaults()` is called in setup.

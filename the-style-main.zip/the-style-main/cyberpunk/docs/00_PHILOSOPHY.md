# 0) Philosophy — Cyberpunk Edition

Cyberpunk Edition is a parallel universe of the same design contract.

Core metaphor:
- Neutrals are **inert panels** (void / gunmetal).
- Accents are **emitted signals** (cyan / magenta).
- Meaning is **stateful** (idle vs active vs alert).

Rules:
- No text glow. Use color + weight + spacing for hierarchy.
- Glows are reserved for focus/active states and primary actions.
- Dark is default. Light is a controlled override.

Performance and accessibility remain non-negotiable.

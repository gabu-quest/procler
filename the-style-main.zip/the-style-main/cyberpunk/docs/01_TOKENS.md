# 1) Tokens (authoritative)

Single source of truth: `src/design/tokens.ts`.

Do:
- extend tokens when needed
- keep semantic meaning consistent

Do not:
- hardcode hex values in components
- invent one-off spacing values
- theme per page

Token groups:
- `color.palette` (identity)
- `color.mode` (readability per mode)
- `color.semantic` (meaning)
- `typography`, `spacing`, `radius`, `shadow`
- `effects.glow` (focus/active only)
- `icons` (Phosphor rules)

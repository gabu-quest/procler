# 2) Naive UI Theme Mapping

Authoritative file: `src/design/naive-theme.ts`.

Strategy:
- put identity and legibility in `common`
- keep component overrides small and intentional
- prefer Naive props over CSS hacks

Allowed/expected overrides:
- Button, Input, Card, DataTable, Modal, Tag, Tooltip, Code, Alert

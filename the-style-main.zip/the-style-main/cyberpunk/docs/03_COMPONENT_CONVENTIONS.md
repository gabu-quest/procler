# 3) Component Conventions

Buttons:
- Primary is an **active signal** (bright + readable).
- Default buttons are tonal panels.
- One primary action per view section.

Forms:
- Use `<n-form>` rules and labeled inputs.
- Focus states must be obvious (border + glow).
- Avoid placeholder-only forms.

Tables:
- Prefer DataTable on desktop.
- Use card-list patterns on mobile rather than squeezing columns.

Notes:
- Notes are “panels with intent.”
- Borders can be circuit-like; do not overuse neon fills.

Logs:
- Mono, fixed height, scroll.
- Consider `aria-live="polite"` for streaming logs.

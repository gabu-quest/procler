# 4) Phosphor Icons — Cyberpunk Rules

Defaults:
- weight: regular
- color: currentColor
- size: ~1em

State mapping (critical):
- Selected/toggled: **fill**
- High-salience emphasis (alerts): **duotone**
- Infrastructure/telemetry only: **thin**
- Do not use duotone everywhere; it becomes visual noise.

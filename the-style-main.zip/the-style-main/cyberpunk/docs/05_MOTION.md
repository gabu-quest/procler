# 5) Motion

Motion should feel precise and fast.
Allowed:
- subtle fades
- small hover/pressed feedback

Forbidden:
- looping attention grabs (pulsing/glitch) in productivity UI

Always respect `prefers-reduced-motion`.

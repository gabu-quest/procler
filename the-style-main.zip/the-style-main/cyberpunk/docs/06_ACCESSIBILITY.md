# 6) Accessibility Checklist

- WCAG AA contrast for text
- Focus always visible (no hiding outlines)
- Keyboard navigable menus/dialogs/forms
- `aria-label` for icon-only buttons
- No meaning conveyed by color alone
- Reduced motion respected

# 7) LLM Rules & Extension Protocol

Treat this system as a contract.

Golden rules:
1) tokens are authoritative
2) no random hex in components
3) no per-page theming hacks
4) glow is reserved for focus/active states only

If you add new tokens:
- update `tokens.ts`
- update `naive-theme.ts` mapping once
- document the change in docs

# Unified Design System Pack — Naive UI Cyberpunk Edition

Audience: **LLM agents integrating this pack into existing Vue 3 + Naive UI repos**.

You are expected to apply this system with minimal drift. Treat it as a contract.

## What this pack contains
- `src/design/tokens.ts` — **authoritative tokens** (single source of truth)
- `src/design/naive-theme.ts` — Naive UI `themeOverrides` mapping (keep stable)
- `src/design/base.css` — minimal styling for raw HTML/markdown content
- `src/design/icons.ts` — Phosphor defaults helper (provide/inject)
- `docs/STYLE_GUIDE_FULL.md` — holistic style guide (human + LLM readable)
- `docs/00_..07_*.md` — split sections (preferred for LLM ingestion)
- `examples/*.vue` — reference integration patterns
- `PATCH_GOSHUIN.md` — patch instructions for the Goshuin/Ceremonial pack (icons + a critical provide() fix)

## Integration checklist (do this in order)
1) **Dependencies**
   - Ensure the repo uses:
     - `naive-ui`
     - `@phosphor-icons/vue`
   - Do not add other deps unless requested.

2) **Copy files**
   - Copy `src/design/*` into the target repo under `src/design/` (or the repo’s agreed design folder).
   - Copy `docs/*` into `docs/`.
   - Copy `examples/*` into a safe place or use them as reference; they are not required for production.

3) **Import base CSS once**
   - Import `src/design/base.css` once at app entry.
   - Do not add large global CSS resets; let Naive handle components.

4) **Root provider**
   - Wrap the app with `<n-config-provider :theme :theme-overrides>`.
   - Use `createDsNaiveThemeOverrides(mode)` to supply overrides.
   - IMPORTANT: call `providePhosphorDefaults()` during setup, not onMounted.

5) **Default mode**
   - Dark is the default. Light is an override.

6) **Do not drift**
   - Do not hardcode hex colors in components.
   - Do not locally theme per page.
   - Add new tokens only when necessary and update the mapping once.

## Fonts (recommended)
Cyberpunk Edition uses:
- Headings: Space Grotesk
- Body: Inter
- Mono: IBM Plex Mono

Google Fonts import:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono&display=swap" rel="stylesheet">
```

## Success criteria
- Tokens are the only source of colors/spacing/typography.
- Naive components render coherently in **dark** mode by default.
- Focus states are visible; reduced-motion is respected.
- Icons follow the cyberpunk weight rules (regular default, fill for selected, duotone for emphasis, thin for infrastructure).
- No “neon everywhere” drift. Glow is reserved for focus/active states only.

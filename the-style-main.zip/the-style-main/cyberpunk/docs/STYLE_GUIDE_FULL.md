# Unified Design System — Naive UI Cyberpunk Edition (Vue 3 + Phosphor)

Holistic guide. For LLM-safe ingestion, prefer the split files in `docs/`.

## Table of contents
0. Philosophy
1. Tokens
2. Naive UI theme mapping
3. Component conventions
4. Phosphor icon rules
5. Motion
6. Accessibility
7. LLM rules

---

# 0) Philosophy — Cyberpunk Edition

Cyberpunk Edition is a parallel universe of the same design contract.

Core metaphor:
- Neutrals are **inert panels** (void / gunmetal).
- Accents are **emitted signals** (cyan / magenta).
- Meaning is **stateful** (idle vs active vs alert).

Rules:
- No text glow. Use color + weight + spacing for hierarchy.
- Glows are reserved for focus/active states and primary actions.
- Dark is default. Light is a controlled override.

Performance and accessibility remain non-negotiable.


---

# 1) Tokens (authoritative)

Single source of truth: `src/design/tokens.ts`.

Do:
- extend tokens when needed
- keep semantic meaning consistent

Do not:
- hardcode hex values in components
- invent one-off spacing values
- theme per page

Token groups:
- `color.palette` (identity)
- `color.mode` (readability per mode)
- `color.semantic` (meaning)
- `typography`, `spacing`, `radius`, `shadow`
- `effects.glow` (focus/active only)
- `icons` (Phosphor rules)


---

# 2) Naive UI Theme Mapping

Authoritative file: `src/design/naive-theme.ts`.

Strategy:
- put identity and legibility in `common`
- keep component overrides small and intentional
- prefer Naive props over CSS hacks

Allowed/expected overrides:
- Button, Input, Card, DataTable, Modal, Tag, Tooltip, Code, Alert


---

# 3) Component Conventions

Buttons:
- Primary is an **active signal** (bright + readable).
- Default buttons are tonal panels.
- One primary action per view section.

Forms:
- Use `<n-form>` rules and labeled inputs.
- Focus states must be obvious (border + glow).
- Avoid placeholder-only forms.

Tables:
- Prefer DataTable on desktop.
- Use card-list patterns on mobile rather than squeezing columns.

Notes:
- Notes are “panels with intent.”
- Borders can be circuit-like; do not overuse neon fills.

Logs:
- Mono, fixed height, scroll.
- Consider `aria-live="polite"` for streaming logs.


---

# 4) Phosphor Icons — Cyberpunk Rules

Defaults:
- weight: regular
- color: currentColor
- size: ~1em

State mapping (critical):
- Selected/toggled: **fill**
- High-salience emphasis (alerts): **duotone**
- Infrastructure/telemetry only: **thin**
- Do not use duotone everywhere; it becomes visual noise.


---

# 5) Motion

Motion should feel precise and fast.
Allowed:
- subtle fades
- small hover/pressed feedback

Forbidden:
- looping attention grabs (pulsing/glitch) in productivity UI

Always respect `prefers-reduced-motion`.


---

# 6) Accessibility Checklist

- WCAG AA contrast for text
- Focus always visible (no hiding outlines)
- Keyboard navigable menus/dialogs/forms
- `aria-label` for icon-only buttons
- No meaning conveyed by color alone
- Reduced motion respected


---

# 7) LLM Rules & Extension Protocol

Treat this system as a contract.

Golden rules:
1) tokens are authoritative
2) no random hex in components
3) no per-page theming hacks
4) glow is reserved for focus/active states only

If you add new tokens:
- update `tokens.ts`
- update `naive-theme.ts` mapping once
- document the change in docs

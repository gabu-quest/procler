<template>
  <n-space vertical size="large">
    <n-space align="center">
      <n-tag>Default (regular)</n-tag>
      <n-button type="primary">
        <template #icon>
          <n-icon :size="18"><PhLightning /></n-icon>
        </template>
        Power
      </n-button>
      <n-button>
        <template #icon>
          <n-icon :size="18"><PhTerminal /></n-icon>
        </template>
        Console
      </n-button>
    </n-space>

    <n-space align="center">
      <n-tag type="info">Emphasis (duotone)</n-tag>
      <n-icon :size="22">
        <PhWarningCircle weight="duotone" />
      </n-icon>
      <span>High-salience alert icon uses duotone.</span>
    </n-space>

    <n-space align="center">
      <n-tag type="success">Selected (fill)</n-tag>
      <n-icon :size="22">
        <PhCheckCircle weight="fill" />
      </n-icon>
      <span>Selected/toggled state uses fill.</span>
    </n-space>

    <n-space align="center">
      <n-tag>Infrastructure (thin)</n-tag>
      <n-icon :size="22">
        <PhCircuitry weight="thin" />
      </n-icon>
      <span>Thin is reserved for secondary HUD/telemetry.</span>
    </n-space>
  </n-space>
</template>

<script setup lang="ts">
import { NButton, NIcon, NSpace, NTag } from "naive-ui";
import {
  PhLightning,
  PhTerminal,
  PhWarningCircle,
  PhCheckCircle,
  PhCircuitry,
} from "@phosphor-icons/vue";
</script>

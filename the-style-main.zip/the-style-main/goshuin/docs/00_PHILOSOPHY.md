# Unified Design System — Naive UI Edition (Vue 3 + Phosphor)

**Purpose:** a token-driven design contract for Vue 3 projects using **Naive UI** and **Phosphor Icons**.

This edition is a Naive-native implementation of your original unified system: calm, high-contrast, culturally anchored accents, and strict consistency over improvisation.

## 0) Philosophy (why & how)

This system is built around these pillars (original intent preserved):

- **Contrast & calm:** dark charcoal + rice-paper creams; vibrant accents are deliberate and sparse.
- **Cultural homage:** goshuin crimson (朱印), gold leaf, sumi-ink blacks, vintage poster indigos.
- **Hierarchy first:** tall serif headings; neutral sans body; mono for code/logs.
- **Whitespace matters:** generous line-height and spacing; layouts breathe by default.
- **One source of truth:** colors/spacing/typography live as tokens, not scattered constants.
- **Accessible by default:** WCAG AA contrast, visible focus, reduced motion support.
- **Islands of interactivity:** static-first mindset; hydrate/animate only where useful.

**Naive UI Edition rule:** prefer `themeOverrides` and component props over global CSS. Global CSS is allowed only for *non-Naive content* (raw HTML, markdown, docs pages).

## 1) Repo integration (minimal)

Recommended layout:

- `src/design/tokens.ts` — **authoritative tokens** (edit this)
- `src/design/naive-theme.ts` — Naive `themeOverrides` (generated mapping)
- `src/design/base.css` — tiny base styles for non-Naive HTML
- `src/design/icons.ts` — Phosphor defaults via provide/inject

Then, in your app root:

- Wrap the app with `<n-config-provider :theme :theme-overrides>`.
- Add `<n-global-style />` once.
- Use Naive providers (`n-message-provider`, `n-dialog-provider`, etc.) at the top.

See: `examples/AppConfigProvider.vue`.

# 1) Token System (authoritative)

**Single Source of Truth:** `src/design/tokens.ts`.

Rules:
- Do **not** hardcode hex colors in components.
- Do **not** introduce “just this once” spacing values.
- When you need a new token, add it to `tokens.ts` and map it through the theme.

## 1.1 Color model

We separate:
- **Palette**: raw named colors (charcoal, paper, indigo…)
- **Mode**: surfaces + readable text per theme (dark/light)
- **Semantic**: meaning (primary/info/success/warning/error/link)

Why:
- Palette preserves identity.
- Mode preserves readability.
- Semantic preserves intent.

## 1.2 Typography model

- Body: modern neutral sans (Inter-ish)
- Headings: tall serif (Cormorant Garamond) for hierarchy
- Mono: IBM Plex Mono for code/logs

Note: Naive theming covers body + mono fonts. Headings for raw HTML are handled in `base.css`.

## 1.3 Spacing model

A 6-step scale keeps layouts consistent:
`0.25rem → 0.5rem → 1rem → 2rem → 3rem → 4rem`

Use it via:
- Naive component props where possible (`size`, `space`, `gap` patterns)
- Your own components/layout wrappers (don’t invent new scales)

## 1.4 Icons model (Phosphor)

Default:
- `weight: regular`
- `size: ~1em`
- `color: currentColor`

Special meanings:
- `fill` is reserved for **selected / active / toggled** states.
- `bold` is allowed for emphasis **sparingly** (alerts, destructive actions).
- `duotone` is decorative; avoid in dense UIs.

These are enforced via `src/design/tokens.ts` + `src/design/icons.ts`.

# 2) Naive UI Theme Mapping

The system maps tokens into Naive UI via `GlobalThemeOverrides`.

Authoritative code: `src/design/naive-theme.ts`

## 2.1 What we override globally (`common`)

We override the Naive common theme vars that matter most for identity and legibility:

- `primaryColor`…: goshuin crimson
- `info/success/warning/error`: calm but semantically distinct
- `bodyColor/cardColor/modalColor/popoverColor`: surfaces
- `textColor1/2/3/Disabled`: readable hierarchy
- `borderColor/dividerColor/hoverColor/pressedColor`: quiet structure
- `fontFamily/fontFamilyMono`: consistent typography
- `borderRadius`, `boxShadow1..3`: consistent geometry and depth

We intentionally **do not** micro-tune every component. The goal is “unified feel” without fighting Naive defaults.

## 2.2 Component overrides (small + intentional)

We tune a short list of high-impact components:

- Button: primary crimson, tonal secondary; explicit focus ring
- Input: calm surfaces; strong focus border; caret matches primary
- Card / Modal / Popover: surfaces + borders + shadow
- DataTable: readable headers, calm hover/striping
- Tag / Tooltip: consistent radii + contrast
- Code: mono surface and legibility
- Alert: foundation for “note blocks”

If you need to theme a component not listed:
1) Try fixing it using `common` vars first.
2) Add a component override only if necessary.
3) Document the change in `docs/07_LLM_RULES.md` (“allowed overrides” list).

## 2.3 Applying the theme

Typical root setup:

- `:theme="darkTheme | lightTheme"` (Naive built-ins)
- `:theme-overrides="createDsNaiveThemeOverrides(mode)"` (this system)

See `examples/AppConfigProvider.vue`.

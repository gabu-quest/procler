# 3) Component Conventions (Naive-first)

This section defines *how we use* Naive components so the UI stays coherent.

## 3.1 Buttons

**Allowed patterns**
- Primary action: `<n-button type="primary" strong>`
- Secondary action: `<n-button>` (tonal) or `secondary` via styling wrapper
- Destructive: `<n-button type="error">` only when truly destructive

**Rules**
- One primary button per view section (per modal/page).
- Prefer labels over icon-only actions (unless the action is universal and obvious).
- Use icons in the `#icon` slot; don’t hand-align SVGs.

**Forbidden**
- Custom gradients.
- Multiple competing primaries in the same row.
- Tiny icon buttons without tooltips or aria-labels.

## 3.2 Forms (Input, Select, Form)

**Standard**
- Use `<n-form>` with explicit `rule` validation (don’t validate “in the button click”).
- Default sizes: `size="medium"` unless density truly requires small.

**Rules**
- Always provide:
  - label text
  - placeholder (optional) that adds meaning, not repeats the label
  - a clear error message
- For required fields: show required status in label, not only in error state.

**Forbidden**
- Placeholder-only forms.
- Hiding validation until submit for fields with obvious constraints.

## 3.3 Tables (DataTable)

**Default choice**: `<n-data-table>` for data, `<n-table>` for simple layout tables.

**Rules**
- Keep columns human-readable (no internal IDs, no JSON dumps).
- Use row hover as “readability aid”, not a click-bait. If rows are clickable, show a clear affordance.
- For mobile, prefer a “card list” layout instead of squeezing DataTable.

**Pattern for mobile**
- Use `useBreakpoints` (VueUse) or your own media query + conditional rendering.
- Desktop: `n-data-table`
- Mobile: `n-card` list or `n-thing` per row.

## 3.4 Notes / Callouts

Your original `.c-note` maps to two patterns:

**Informational note**
- `<n-alert type="info" :bordered="true">`
- Use concise titles and a single idea.

**Paper note (goshuin vibe)**
- Use `<n-card>` with a left border colored `noteBorder` (poster indigo).
- Light paper surface inside the card is allowed if the surrounding surface is dark.

Rule: notes are for clarity, not decoration.

## 3.5 Logs / Terminal Views

Naive has logging primitives, but your “log stream” is a *special component*.

**Recommended approach**
- Wrap logs in a component that:
  - uses mono font
  - has a fixed-height scroll container
  - supports `aria-live="polite"` for updates
  - color-codes levels (info/warn/error) using semantic tokens

Rule: logs should look like tools, not like marketing dashboards.

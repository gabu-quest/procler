# 4) Phosphor Icons (rules + patterns)

We standardize on `@phosphor-icons/vue` (tree-shakeable icon components).

## 4.1 Global defaults (via provide/inject)

Phosphor supports default styling through Vue’s `provide`/`inject`. Use this at the app root:

- `color: currentColor`
- `size: ~1em`
- `weight: regular`

Implementation: `src/design/icons.ts`.

## 4.2 Size scale

- `xs`: 0.9em (dense tables)
- `sm`: 1em (inline)
- `md`: 1.05em (default)
- `lg`: 1.25em (buttons/toolbars)
- `xl`: 1.5em (empty states)
- `hero`: 2em (rare: marketing/landing only)

## 4.3 Weight rules

- `regular`: default UI
- `bold`: emphasis (danger, “important”, high-salience callouts)
- `fill`: selected/toggled states (on/off, active nav)
- `duotone`: decorative only (avoid in dense productivity UIs)

## 4.4 Naive UI integration pattern

Use `NIcon` to keep icon sizing aligned with Naive controls:

```vue
<n-button type="primary">
  <template #icon>
    <n-icon :size="18"><PhStamp /></n-icon>
  </template>
  Stamp Action
</n-button>
```

Full example: `examples/IconExamples.vue`.

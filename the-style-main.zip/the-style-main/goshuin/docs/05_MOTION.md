# 5) Motion & Interaction

Rule: motion exists to support comprehension, not to entertain.

## 5.1 Allowed motion

- Subtle fades for appearance/disappearance
- Small transforms for micro-feedback (hover/pressed), kept within Naive defaults

## 5.2 Forbidden motion

- Attention-grabbing loops (pulsing, bouncing, spinning) unless part of a loading indicator
- Large page transitions for dashboards/tools

## 5.3 Reduced motion

Always respect `prefers-reduced-motion`.

- Naive components already behave reasonably.
- Your custom CSS should disable transitions and scroll behavior for reduced motion users.

See `src/design/base.css` for the baseline implementation.

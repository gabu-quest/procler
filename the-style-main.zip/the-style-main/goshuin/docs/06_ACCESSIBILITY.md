# 6) Accessibility Checklist (non-negotiable)

## Contrast & color
- Target WCAG AA contrast for text.
- Never rely on color alone to convey meaning (use icon + label, or icon + shape).

## Focus
- Focus states must always be visible.
- For custom components, ensure `:focus-visible` styling is present.
- For icon-only buttons, always provide `aria-label`.

## Keyboard
- All menus, dialogs, drawers, and forms must be keyboard-navigable.
- Ensure “escape” closes modals where appropriate.

## Screen readers
- Use semantic HTML where possible.
- For log updates / streaming statuses, use `aria-live="polite"`.

## Motion
- Respect `prefers-reduced-motion`.
- Don’t gate information behind hover-only behaviors.

## Content
- Headings should be hierarchical (h1 → h2 → h3).
- Link text should be descriptive (“View logs” not “Click here”).

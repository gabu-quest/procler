# 7) Rules for LLMs & Future Devs (read this before you touch anything)

This repo treats the design system as a **contract**.

## Golden rules
1) **No random hex.** If you need a new color, add a token.
2) **No local theming “just for this page.”** If you need a variant, add a token or component convention.
3) **No CSS wars with Naive.** Prefer props and `themeOverrides`.
4) **Dark-first.** Light mode is an override. Don’t build features that only look good in light mode.

## Single Source of Truth
- Tokens live in: `src/design/tokens.ts`
- Naive mapping lives in: `src/design/naive-theme.ts`
- Base CSS is minimal: `src/design/base.css`
- Icon defaults: `src/design/icons.ts`

## Allowed overrides list
Only these component overrides are expected to exist:
- common
- Button
- Input
- Card
- DataTable
- Modal
- Tag
- Tooltip
- Code
- Alert

If you add another override:
- Document it here.
- Add the rationale and acceptance criteria.
- Ensure it doesn’t cause regressions across dark + light modes.

## Extension protocol
When extending the system:
1) Write the new requirement in a short paragraph.
2) Decide: token change vs. component convention vs. new component wrapper.
3) Implement the smallest change that satisfies the requirement.
4) Update docs.

## Parking lot
Ideas that are cool but not required go in `docs/PARKING_LOT.md`.
Do not implement them “while you’re in there”.

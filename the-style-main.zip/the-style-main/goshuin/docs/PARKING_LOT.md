# PARKING LOT

Drop ideas here when they are tempting but not required.

- [ ] ...

# Unified Design System — Naive UI Edition

Start here.

## What’s in this zip
- `docs/STYLE_GUIDE_FULL.md` — one-file holistic guide
- `docs/00_..07_*.md` — split docs for safer LLM consumption
- `src/design/tokens.ts` — authoritative tokens (**edit this**)
- `src/design/naive-theme.ts` — Naive theme mapping (generated-style, stable)
- `src/design/base.css` — minimal base styles for raw HTML/content
- `src/design/icons.ts` — Phosphor defaults helper
- `examples/*.vue` — usage patterns

## Quick start (copy/paste)
1) Install deps:
   - `naive-ui`
   - `@phosphor-icons/vue` (tree-shakeable icons)

2) Import base CSS once (if you have raw HTML/markdown pages):
   - `import "@/design/base.css"`

3) Wrap your app with `n-config-provider` and apply overrides.
   See `examples/AppConfigProvider.vue`.

## Editing rules
- Change tokens in `src/design/tokens.ts`
- Avoid editing theme overrides directly unless you’re changing the mapping strategy.
## Fonts (recommended)
Your original system assumes these fonts:
- Cormorant Garamond (headings)
- Inter (body)
- IBM Plex Mono (code/logs)

Quick HTML `<head>` import (Google Fonts):

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;700&family=Inter:wght@400;500;700&family=IBM+Plex+Mono&display=swap" rel="stylesheet">
```

# Unified Design System — Naive UI Edition (Vue 3 + Phosphor)

This is the **holistic** design contract. If you prefer smaller chunks for LLM safety, see the split files:
`docs/00_PHILOSOPHY.md` through `docs/07_LLM_RULES.md`.

---

## Table of contents
0. Philosophy & goals
1. Token system (authoritative)
2. Naive UI theme mapping
3. Component conventions
4. Phosphor icon rules
5. Motion & interaction
6. Accessibility checklist
7. Rules for LLMs & future devs
8. Copy/paste setup snippets

---

# Unified Design System — Naive UI Edition (Vue 3 + Phosphor)

**Purpose:** a token-driven design contract for Vue 3 projects using **Naive UI** and **Phosphor Icons**.

This edition is a Naive-native implementation of your original unified system: calm, high-contrast, culturally anchored accents, and strict consistency over improvisation.

## 0) Philosophy (why & how)

This system is built around these pillars (original intent preserved):

- **Contrast & calm:** dark charcoal + rice-paper creams; vibrant accents are deliberate and sparse.
- **Cultural homage:** goshuin crimson (朱印), gold leaf, sumi-ink blacks, vintage poster indigos.
- **Hierarchy first:** tall serif headings; neutral sans body; mono for code/logs.
- **Whitespace matters:** generous line-height and spacing; layouts breathe by default.
- **One source of truth:** colors/spacing/typography live as tokens, not scattered constants.
- **Accessible by default:** WCAG AA contrast, visible focus, reduced motion support.
- **Islands of interactivity:** static-first mindset; hydrate/animate only where useful.

**Naive UI Edition rule:** prefer `themeOverrides` and component props over global CSS. Global CSS is allowed only for *non-Naive content* (raw HTML, markdown, docs pages).

## 1) Repo integration (minimal)

Recommended layout:

- `src/design/tokens.ts` — **authoritative tokens** (edit this)
- `src/design/naive-theme.ts` — Naive `themeOverrides` (generated mapping)
- `src/design/base.css` — tiny base styles for non-Naive HTML
- `src/design/icons.ts` — Phosphor defaults via provide/inject

Then, in your app root:

- Wrap the app with `<n-config-provider :theme :theme-overrides>`.
- Add `<n-global-style />` once.
- Use Naive providers (`n-message-provider`, `n-dialog-provider`, etc.) at the top.

See: `examples/AppConfigProvider.vue`.


---

# 1) Token System (authoritative)

**Single Source of Truth:** `src/design/tokens.ts`.

Rules:
- Do **not** hardcode hex colors in components.
- Do **not** introduce “just this once” spacing values.
- When you need a new token, add it to `tokens.ts` and map it through the theme.

## 1.1 Color model

We separate:
- **Palette**: raw named colors (charcoal, paper, indigo…)
- **Mode**: surfaces + readable text per theme (dark/light)
- **Semantic**: meaning (primary/info/success/warning/error/link)

Why:
- Palette preserves identity.
- Mode preserves readability.
- Semantic preserves intent.

## 1.2 Typography model

- Body: modern neutral sans (Inter-ish)
- Headings: tall serif (Cormorant Garamond) for hierarchy
- Mono: IBM Plex Mono for code/logs

Note: Naive theming covers body + mono fonts. Headings for raw HTML are handled in `base.css`.

## 1.3 Spacing model

A 6-step scale keeps layouts consistent:
`0.25rem → 0.5rem → 1rem → 2rem → 3rem → 4rem`

Use it via:
- Naive component props where possible (`size`, `space`, `gap` patterns)
- Your own components/layout wrappers (don’t invent new scales)

## 1.4 Icons model (Phosphor)

Default:
- `weight: regular`
- `size: ~1em`
- `color: currentColor`

Special meanings:
- `fill` is reserved for **selected / active / toggled** states.
- `bold` is allowed for emphasis **sparingly** (alerts, destructive actions).
- `duotone` is decorative; avoid in dense UIs.

These are enforced via `src/design/tokens.ts` + `src/design/icons.ts`.


---

# 2) Naive UI Theme Mapping

The system maps tokens into Naive UI via `GlobalThemeOverrides`.

Authoritative code: `src/design/naive-theme.ts`

## 2.1 What we override globally (`common`)

We override the Naive common theme vars that matter most for identity and legibility:

- `primaryColor`…: goshuin crimson
- `info/success/warning/error`: calm but semantically distinct
- `bodyColor/cardColor/modalColor/popoverColor`: surfaces
- `textColor1/2/3/Disabled`: readable hierarchy
- `borderColor/dividerColor/hoverColor/pressedColor`: quiet structure
- `fontFamily/fontFamilyMono`: consistent typography
- `borderRadius`, `boxShadow1..3`: consistent geometry and depth

We intentionally **do not** micro-tune every component. The goal is “unified feel” without fighting Naive defaults.

## 2.2 Component overrides (small + intentional)

We tune a short list of high-impact components:

- Button: primary crimson, tonal secondary; explicit focus ring
- Input: calm surfaces; strong focus border; caret matches primary
- Card / Modal / Popover: surfaces + borders + shadow
- DataTable: readable headers, calm hover/striping
- Tag / Tooltip: consistent radii + contrast
- Code: mono surface and legibility
- Alert: foundation for “note blocks”

If you need to theme a component not listed:
1) Try fixing it using `common` vars first.
2) Add a component override only if necessary.
3) Document the change in `docs/07_LLM_RULES.md` (“allowed overrides” list).

## 2.3 Applying the theme

Typical root setup:

- `:theme="darkTheme | lightTheme"` (Naive built-ins)
- `:theme-overrides="createDsNaiveThemeOverrides(mode)"` (this system)

See `examples/AppConfigProvider.vue`.


---

# 3) Component Conventions (Naive-first)

This section defines *how we use* Naive components so the UI stays coherent.

## 3.1 Buttons

**Allowed patterns**
- Primary action: `<n-button type="primary" strong>`
- Secondary action: `<n-button>` (tonal) or `secondary` via styling wrapper
- Destructive: `<n-button type="error">` only when truly destructive

**Rules**
- One primary button per view section (per modal/page).
- Prefer labels over icon-only actions (unless the action is universal and obvious).
- Use icons in the `#icon` slot; don’t hand-align SVGs.

**Forbidden**
- Custom gradients.
- Multiple competing primaries in the same row.
- Tiny icon buttons without tooltips or aria-labels.

## 3.2 Forms (Input, Select, Form)

**Standard**
- Use `<n-form>` with explicit `rule` validation (don’t validate “in the button click”).
- Default sizes: `size="medium"` unless density truly requires small.

**Rules**
- Always provide:
  - label text
  - placeholder (optional) that adds meaning, not repeats the label
  - a clear error message
- For required fields: show required status in label, not only in error state.

**Forbidden**
- Placeholder-only forms.
- Hiding validation until submit for fields with obvious constraints.

## 3.3 Tables (DataTable)

**Default choice**: `<n-data-table>` for data, `<n-table>` for simple layout tables.

**Rules**
- Keep columns human-readable (no internal IDs, no JSON dumps).
- Use row hover as “readability aid”, not a click-bait. If rows are clickable, show a clear affordance.
- For mobile, prefer a “card list” layout instead of squeezing DataTable.

**Pattern for mobile**
- Use `useBreakpoints` (VueUse) or your own media query + conditional rendering.
- Desktop: `n-data-table`
- Mobile: `n-card` list or `n-thing` per row.

## 3.4 Notes / Callouts

Your original `.c-note` maps to two patterns:

**Informational note**
- `<n-alert type="info" :bordered="true">`
- Use concise titles and a single idea.

**Paper note (goshuin vibe)**
- Use `<n-card>` with a left border colored `noteBorder` (poster indigo).
- Light paper surface inside the card is allowed if the surrounding surface is dark.

Rule: notes are for clarity, not decoration.

## 3.5 Logs / Terminal Views

Naive has logging primitives, but your “log stream” is a *special component*.

**Recommended approach**
- Wrap logs in a component that:
  - uses mono font
  - has a fixed-height scroll container
  - supports `aria-live="polite"` for updates
  - color-codes levels (info/warn/error) using semantic tokens

Rule: logs should look like tools, not like marketing dashboards.


---

# 4) Phosphor Icons (rules + patterns)

We standardize on `@phosphor-icons/vue` (tree-shakeable icon components).

## 4.1 Global defaults (via provide/inject)

Phosphor supports default styling through Vue’s `provide`/`inject`. Use this at the app root:

- `color: currentColor`
- `size: ~1em`
- `weight: regular`

Implementation: `src/design/icons.ts`.

## 4.2 Size scale

- `xs`: 0.9em (dense tables)
- `sm`: 1em (inline)
- `md`: 1.05em (default)
- `lg`: 1.25em (buttons/toolbars)
- `xl`: 1.5em (empty states)
- `hero`: 2em (rare: marketing/landing only)

## 4.3 Weight rules

- `regular`: default UI
- `bold`: emphasis (danger, “important”, high-salience callouts)
- `fill`: selected/toggled states (on/off, active nav)
- `duotone`: decorative only (avoid in dense productivity UIs)

## 4.4 Naive UI integration pattern

Use `NIcon` to keep icon sizing aligned with Naive controls:

```vue
<n-button type="primary">
  <template #icon>
    <n-icon :size="18"><PhStamp /></n-icon>
  </template>
  Stamp Action
</n-button>
```

Full example: `examples/IconExamples.vue`.


---

# 5) Motion & Interaction

Rule: motion exists to support comprehension, not to entertain.

## 5.1 Allowed motion

- Subtle fades for appearance/disappearance
- Small transforms for micro-feedback (hover/pressed), kept within Naive defaults

## 5.2 Forbidden motion

- Attention-grabbing loops (pulsing, bouncing, spinning) unless part of a loading indicator
- Large page transitions for dashboards/tools

## 5.3 Reduced motion

Always respect `prefers-reduced-motion`.

- Naive components already behave reasonably.
- Your custom CSS should disable transitions and scroll behavior for reduced motion users.

See `src/design/base.css` for the baseline implementation.


---

# 6) Accessibility Checklist (non-negotiable)

## Contrast & color
- Target WCAG AA contrast for text.
- Never rely on color alone to convey meaning (use icon + label, or icon + shape).

## Focus
- Focus states must always be visible.
- For custom components, ensure `:focus-visible` styling is present.
- For icon-only buttons, always provide `aria-label`.

## Keyboard
- All menus, dialogs, drawers, and forms must be keyboard-navigable.
- Ensure “escape” closes modals where appropriate.

## Screen readers
- Use semantic HTML where possible.
- For log updates / streaming statuses, use `aria-live="polite"`.

## Motion
- Respect `prefers-reduced-motion`.
- Don’t gate information behind hover-only behaviors.

## Content
- Headings should be hierarchical (h1 → h2 → h3).
- Link text should be descriptive (“View logs” not “Click here”).


---

# 7) Rules for LLMs & Future Devs (read this before you touch anything)

This repo treats the design system as a **contract**.

## Golden rules
1) **No random hex.** If you need a new color, add a token.
2) **No local theming “just for this page.”** If you need a variant, add a token or component convention.
3) **No CSS wars with Naive.** Prefer props and `themeOverrides`.
4) **Dark-first.** Light mode is an override. Don’t build features that only look good in light mode.

## Single Source of Truth
- Tokens live in: `src/design/tokens.ts`
- Naive mapping lives in: `src/design/naive-theme.ts`
- Base CSS is minimal: `src/design/base.css`
- Icon defaults: `src/design/icons.ts`

## Allowed overrides list
Only these component overrides are expected to exist:
- common
- Button
- Input
- Card
- DataTable
- Modal
- Tag
- Tooltip
- Code
- Alert

If you add another override:
- Document it here.
- Add the rationale and acceptance criteria.
- Ensure it doesn’t cause regressions across dark + light modes.

## Extension protocol
When extending the system:
1) Write the new requirement in a short paragraph.
2) Decide: token change vs. component convention vs. new component wrapper.
3) Implement the smallest change that satisfies the requirement.
4) Update docs.

## Parking lot
Ideas that are cool but not required go in `docs/PARKING_LOT.md`.
Do not implement them “while you’re in there”.


---

## 8) Copy/paste setup snippets

### 8.1 Root config provider (pattern)
See: `examples/AppConfigProvider.vue`

### 8.2 Icon usage (pattern)
See: `examples/IconExamples.vue`

### 8.3 “One source of truth” recap
- Tokens: `src/design/tokens.ts`
- Naive mapping: `src/design/naive-theme.ts`
- Base HTML: `src/design/base.css`
- Icon defaults: `src/design/icons.ts`

---

## Sources / references (for maintenance)
- Naive UI common theme variables list (TypeScript) — used to keep override keys aligned: https://app.unpkg.com/naive-ui@2.43.1/files/es/_styles/common/light.d.ts
- Phosphor Icons Vue package docs (installation, usage, provide/inject defaults): https://github.com/phosphor-icons/vue

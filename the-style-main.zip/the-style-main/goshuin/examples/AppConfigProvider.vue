<template>
  <n-config-provider :theme="naiveTheme" :theme-overrides="themeOverrides">
    <n-global-style />
    <n-message-provider>
      <n-notification-provider>
        <n-dialog-provider>
          <div class="app-surface">
            <slot />
          </div>
        </n-dialog-provider>
      </n-notification-provider>
    </n-message-provider>
  </n-config-provider>
</template>

<script setup lang="ts">
import { computed, onMounted } from "vue";
import { darkTheme, lightTheme } from "naive-ui";
import { createDsNaiveThemeOverrides } from "../src/design/naive-theme";
import { providePhosphorDefaults } from "../src/design/icons";

// Replace with your own store (pinia, vueuse, etc.). Dark is default.
const prefersDark = computed(() => {
  // Cheap default: use prefers-color-scheme, then persist in your app state.
  return window.matchMedia?.("(prefers-color-scheme: dark)")?.matches ?? true;
});

const mode = computed(() => (prefersDark.value ? "dark" : "light") as const);
const naiveTheme = computed(() => (mode.value === "dark" ? darkTheme : lightTheme));
const themeOverrides = computed(() => createDsNaiveThemeOverrides(mode.value));

onMounted(() => {
  providePhosphorDefaults();
});
</script>

<style scoped>
.app-surface {
  min-height: 100vh;
  background: var(--n-body-color);
  color: var(--n-text-color-1);
}
</style>

<template>
  <n-space align="center">
    <n-button type="primary" strong>
      <template #icon>
        <n-icon :size="18">
          <PhStamp />
        </n-icon>
      </template>
      Stamp Action
    </n-button>

    <n-button>
      <template #icon>
        <n-icon :size="18">
          <PhInfo />
        </n-icon>
      </template>
      Details
    </n-button>

    <n-tag type="warning">
      <n-icon :size="16" style="margin-right: 6px">
        <PhWarning />
      </n-icon>
      Warning
    </n-tag>
  </n-space>
</template>

<script setup lang="ts">
import { NButton, NIcon, NSpace, NTag } from "naive-ui";
import { PhStamp, PhInfo, PhWarning } from "@phosphor-icons/vue";
</script>

/* eslint-disable @typescript-eslint/consistent-type-definitions */
/**
 * Unified Design System — Naive UI Edition
 * Single source of truth for all tokens.
 *
 * Edit THIS file. Everything else should reference it.
 */

export type DsMode = "dark" | "light";

export const ds = {
  meta: {
    name: "Unified Design System — Naive UI Edition",
    version: "1.0.0",
    updated: "2025-12-12",
    notes:
      "Dark-first, token-driven. Cultural accents inspired by goshuin (朱印), sumi-ink blacks, and vintage indigos. Keep accents sparse.",
  },

  /** Color tokens: raw palette + semantic meaning. */
  color: {
    palette: {
      // Neutrals
      charcoal: "#181818",
      paper: "#f8f4e3",
      ink: "#1c1c1c",
      fog: "#e4e4e4",

      // Wada Sanzo / goshuin accents
      goshuinCrimson: "#d70000",
      goldLeaf: "#c6a300",
      posterIndigo: "#242942",
      skyAccent: "#7ec8e3",

      // Supporting semantics (kept subdued)
      pineGreen: "#2c8c4a",
      ember: "#b00020",
    },

    /** Mode-specific surfaces and text. */
    mode: {
      dark: {
        bg: "#181818",
        surface1: "#1f1f1f",
        surface2: "#242424",
        surface3: "#2a2a2a",
        paperSurface: "#f8f4e3",

        text1: "#e4e4e4",
        text2: "rgba(228, 228, 228, 0.78)",
        text3: "rgba(228, 228, 228, 0.58)",
        textDisabled: "rgba(228, 228, 228, 0.38)",

        border: "rgba(255, 255, 255, 0.10)",
        divider: "rgba(255, 255, 255, 0.08)",
        hover: "rgba(255, 255, 255, 0.06)",
        pressed: "rgba(255, 255, 255, 0.10)",
        focusRing: "#7ec8e3",
      },

      light: {
        bg: "#fafafa",
        surface1: "#ffffff",
        surface2: "#f5f5f5",
        surface3: "#efefef",
        paperSurface: "#f8f4e3",

        text1: "#242424",
        text2: "rgba(36, 36, 36, 0.78)",
        text3: "rgba(36, 36, 36, 0.58)",
        textDisabled: "rgba(36, 36, 36, 0.38)",

        border: "rgba(0, 0, 0, 0.12)",
        divider: "rgba(0, 0, 0, 0.10)",
        hover: "rgba(0, 0, 0, 0.05)",
        pressed: "rgba(0, 0, 0, 0.10)",
        focusRing: "#242942",
      },
    } satisfies Record<DsMode, Record<string, string>>,

    /** Semantic intent — these should be consistent across modes. */
    semantic: {
      primary: "#d70000", // goshuin crimson
      info: "#7ec8e3",
      success: "#2c8c4a",
      warning: "#c6a300",
      error: "#b00020",
      link: "#7ec8e3",
      noteBorder: "#242942",
    },
  },

  typography: {
    font: {
      body: "Inter, system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
      heading: "'Cormorant Garamond', ui-serif, Georgia, serif",
      mono: "'IBM Plex Mono', ui-monospace, SFMono-Regular, Menlo, Consolas, monospace",
    },
    size: {
      base: "14px",
      tiny: "12px",
      small: "14px",
      medium: "14px",
      large: "15px",
      huge: "16px",
      // Non-Naive (content headings)
      h1: "2.5rem",
      h2: "2rem",
      h3: "1.5rem",
    },
    weight: {
      normal: 400,
      strong: 600,
      heading: 600,
    },
    lineHeight: {
      body: 1.7,
      heading: 1.25,
      compact: 1.3,
    },
  },

  /** Spacing scale: keep it boring and repeatable. */
  spacing: {
    1: "0.25rem",
    2: "0.5rem",
    3: "1rem",
    4: "2rem",
    5: "3rem",
    6: "4rem",
  },

  radius: {
    sm: "4px",
    md: "6px",
    lg: "8px",
  },

  shadow: {
    // Used sparingly; most UIs should look "ink on paper", not "floating glass".
    1: "0 2px 10px rgba(0, 0, 0, 0.25)",
    2: "0 6px 20px rgba(0, 0, 0, 0.28)",
    3: "0 12px 40px rgba(0, 0, 0, 0.30)",
  },

  motion: {
    duration: {
      fast: "120ms",
      base: "180ms",
      slow: "240ms",
    },
    easing: {
      inOut: "cubic-bezier(.4, 0, .2, 1)",
      out: "cubic-bezier(0, 0, .2, 1)",
      in: "cubic-bezier(.4, 0, 1, 1)",
    },
  },

  icons: {
    /** Default Phosphor context values. */
    defaults: {
      color: "currentColor",
      size: "1.05em",
      weight: "regular" as const,
      mirrored: false,
    },
    size: {
      xs: "0.9em",
      sm: "1em",
      md: "1.05em",
      lg: "1.25em",
      xl: "1.5em",
      hero: "2em",
    },
    weight: {
      ui: "regular" as const,
      emphasis: "bold" as const,
      selected: "fill" as const,
      decorative: "duotone" as const, // use sparingly
    },
  },

  breakpoints: {
    xsMax: 399,
    smMin: 400,
    mdMin: 640,
    lgMin: 960,
  },
} as const;

export type DesignSystem = typeof ds;

/**
 * Helper: choose mode from a boolean or a string.
 */
export function normalizeMode(mode: DsMode | boolean): DsMode {
  return mode === true ? "dark" : mode === false ? "light" : mode;
}

/**
 * Helper: tiny alpha utility (hex + alpha -> rgba).
 * Intended for documentation + theme glue, not for heavy color math.
 */
export function rgba(hex: string, alpha: number): string {
  const h = hex.replace("#", "").trim();
  if (!/^[0-9a-fA-F]{6}$/.test(h)) return hex;
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  const a = Math.max(0, Math.min(1, alpha));
  return `rgba(${r}, ${g}, ${b}, ${a})`;
}
